Hello.

Here's how our emulator works:

The "emulator" consists of "util.ts" and "emulator.ts".
util.ts has an abstract App class which your App must implement.
The emulator will:
- call your App's init() method, passing it:
  * a canvas object - draw on this, use it as you will. The emulator gives
    you _no_ structure - just a blank canvas. The emulator doesn't clear it for you.
  * an Events object - you need to basically set listeners here - see example app
  * a Sensors object, containing values of the "sensors" of the app.

- call App.doTick() 60 times a second (yay, locked framerate)

As long as your app implements App inside util.ts, you should be fine.

To run your app, create a .html page (like first-app.html), set the
app_path variable to what it sounds like and set is_test to false (yay legacy).

Basically, just copy the first-app and change it.

Good luck!

(if you get really stuck:
- hosty179@student.otago.ac.nz
- stefan.pedersen@otago.ac.nz
- brandon.wyatt@otago.ac.nz
- tcrisp@cs.otago.ac.nz
We like beers.)
