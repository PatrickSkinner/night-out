define(["require", "./emulator", app_path], function (require, emulator, app) {
    "use strict";
    if(is_test) {
      emulator.run(new app.Test());
    } else {
      emulator.run(new app.Main());
    }
});
