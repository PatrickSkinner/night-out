var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../util/util", "../util/util", "../util/util", "../apps/first-app/first-app"], function (require, exports, util_1, util_2, util_3, first_app_1) {
    "use strict";
    var lineObject = (function () {
        function lineObject() {
        }
        return lineObject;
    }());
    ;
    var TestObject = (function () {
        function TestObject() {
        }
        return TestObject;
    }());
    var Test = (function (_super) {
        __extends(Test, _super);
        function Test() {
            _super.apply(this, arguments);
            this.runTest = function (t) {
                util_2.clearLog();
                t.test();
                t.result = (util_1.getLog() == t.expectedOut);
            };
            this.tests = [];
        }
        Test.prototype.init = function (screen, events, sensors) {
            var _this = this;
            this.test_ev = events;
            this.test_sens = sensors;
            _super.prototype.init.call(this, screen, events, sensors);
            this.objectButton = {
                startX: this.screen.width - 80,
                startY: 0,
                endX: this.screen.width,
                endY: 35,
                text: "run tests"
            };
            var old_tap_event = this.test_ev.onTapEvent;
            var hoist = this;
            this.test_ev.onTapEvent = function (x, y) {
                old_tap_event(x, y);
                if (x > hoist.objectButton.startX && x < hoist.objectButton.endX &&
                    y > hoist.objectButton.startY && y < hoist.objectButton.endY) {
                    for (var _i = 0, _a = hoist.tests; _i < _a.length; _i++) {
                        var t = _a[_i];
                        hoist.runTest(t);
                    }
                    util_2.clearLog();
                    for (var _b = 0, _c = hoist.tests; _b < _c.length; _b++) {
                        var t = _c[_b];
                        util_3.logOneLine((t.result ? "Passed: " : "Failed: ") + t.expectedOut);
                    }
                }
            };
            this.tests.push({
                test: function () { _this.test_ev.onTapEvent(30, 30); },
                expectedOut: "You Tapped: 30, 30\n",
                result: false
            });
            this.tests.push({
                test: function () { _this.test_ev.onTapEvent(20, 40); },
                expectedOut: "You Tapped: 20, 40\n",
                result: false
            });
            this.tests.push({
                test: function () { _this.test_ev.onSwipeEvent(0, 0, 0, 50, "horizontal"); },
                expectedOut: "You swiped: (0,0) -> (0,50): horizontal\n",
                result: false
            });
            this.tests.push({
                test: function () { _this.test_ev.onSwipeEvent(50, 50, 50, 200, "vertical"); },
                expectedOut: "You swiped: (50,50) -> (50,200): vertical\n",
                result: false
            });
            this.tests.push({
                test: function () {
                    _this.sensors.sensors["height"] = 667;
                    _this.sensorUpdated("height");
                },
                expectedOut: "height updated to: 667\n",
                result: false
            });
            this.title = "Testing: \"" + this.title + "\"";
        };
        ;
        Test.prototype.doTick = function () {
            _super.prototype.doTick.call(this);
            this.ctx.fillStyle = "#00ffff";
            this.ctx.fillRect(this.objectButton.startX, this.objectButton.startY, this.objectButton.endX - this.objectButton.startX, this.objectButton.endY - this.objectButton.startY);
            this.ctx.fillStyle = "#000000";
            this.ctx.fillText(this.objectButton.text, this.objectButton.startX + 5, this.objectButton.startY + 12);
        };
        ;
        Test.prototype.sensorUpdated = function (sensor) {
            _super.prototype.sensorUpdated.call(this, sensor);
        };
        ;
        return Test;
    }(first_app_1.Main));
    exports.Test = Test;
});
