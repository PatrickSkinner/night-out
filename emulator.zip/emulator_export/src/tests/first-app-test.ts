import {log} from "../util/util";
import {getLog} from "../util/util";
import {clearLog} from "../util/util";
import {logOneLine} from "../util/util";
import {getKeyboardInput} from "../util/util";
import {Events} from "../util/util";
import {Main} from "../apps/first-app/first-app";
import {Sensors} from "../util/util";

class lineObject {
  radius: number;
  toX: number;
  toY: number;
  theta: number;
  color: string;
};

class TestObject {
  test: ()=>void;
  expectedOut: string;
  result: boolean;
}

class Test extends Main {
  test_sens: Sensors;
  test_ev: Events;

  runTest = function(t: TestObject): void {
    clearLog();
    t.test();
    t.result = (getLog() == t.expectedOut);
  };

  tests:TestObject[] = [];

  objectButton: {
    startX: number,
    startY: number,
    endX: number,
    endY:number,
    text: string
  };

  init(screen: HTMLCanvasElement, events: Events, sensors: Sensors): void {
    this.test_ev = events;
    this.test_sens = sensors;
    super.init(screen, events, sensors);

    this.objectButton =  {
        startX: this.screen.width-80,
        startY: 0,
        endX: this.screen.width,
        endY: 35,
        text: "run tests"
      }

    var old_tap_event = this.test_ev.onTapEvent;
    var hoist = this;

    this.test_ev.onTapEvent = function(x, y) {
      old_tap_event(x, y);
      if(x > hoist.objectButton.startX && x < hoist.objectButton.endX &&
         y > hoist.objectButton.startY && y < hoist.objectButton.endY) {

         for(var t of hoist.tests) {
           hoist.runTest(t);
         }

         clearLog();

         for(var t of hoist.tests) {
           logOneLine(
             (t.result ? "Passed: " : "Failed: ") + t.expectedOut
           );
         }
       }
    };

    // Test some taps
    this.tests.push({
      test: () => {this.test_ev.onTapEvent(30, 30)},
      expectedOut: "You Tapped: 30, 30\n",
      result: false
    });
    this.tests.push({
      test: () => {this.test_ev.onTapEvent(20, 40)},
      expectedOut: "You Tapped: 20, 40\n",
      result: false
    });
    // Test horizontal swipe
    this.tests.push({
      test: () => {this.test_ev.onSwipeEvent(0, 0, 0, 50, "horizontal")},
      expectedOut: "You swiped: (0,0) -> (0,50): horizontal\n",
      result: false
    });
    this.tests.push({
      test: () => {this.test_ev.onSwipeEvent(50, 50, 50, 200, "vertical")},
      expectedOut: "You swiped: (50,50) -> (50,200): vertical\n",
      result: false
    });
    this.tests.push({
      test: () => {
        this.sensors.sensors["height"] = 667;
        this.sensorUpdated("height");
      },
      expectedOut: "height updated to: 667\n",
      result: false
    });

    this.title = "Testing: \"" + this.title + "\"";
  };

  doTick(): void {
    super.doTick();
    this.ctx.fillStyle = "#00ffff";
    this.ctx.fillRect(
      this.objectButton.startX,
      this.objectButton.startY,
      this.objectButton.endX-this.objectButton.startX,
      this.objectButton.endY-this.objectButton.startY
    );

    this.ctx.fillStyle = "#000000";
    this.ctx.fillText(this.objectButton.text, this.objectButton.startX+5, this.objectButton.startY+12)
  };

  sensorUpdated(sensor: string): void {
    super.sensorUpdated(sensor);
  };
}

export {Test};
