export class Events {
    public onTapEvent(x: number, y: number): void {};
    public onSwipeEvent(startX:number, startY:number,
                        endX: number, endY:number,
                        orientation:string): void{};
}

/** Sensor class. Note that to get at the sensors, you need to call
  * _whatever_you_import_as_.sensors because the sensors live in the sensors
  * object inside the sensors class. Phew.
*/
export class Sensors {
  public sensors = {
      "gps_lat": 0,
      "gps_lon": 0,
      "ambient_light":0,
      "height":0,
      "accelerometer":0,
      "magnetometer":0,
      "heartbeat":0,
      "blood_o2":0,
      "blood_co2":0,
      "conductance":0,
      "gyroscope":0,
      "barometer":0,
      "temp_skin":0,
      "temp_ambient":0
  };
}

export function setPersistentData(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

export function getPersistentData(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}


/** Define an abstract class for our app.
 * It needs to have a "main" method.
 */
export abstract class App {
    abstract init(screen:HTMLCanvasElement, events:Events, sensors:Sensors): void;
    abstract doTick(): void;
    abstract sensorUpdated(sensor:string): void;
}

/** Log something in the "console" textarea.
 * @param message The message to log - must have toString() method
 */
export function log(message: {toString: any}, color?:string): void { // accepts anything that has a toString method
    var console = <HTMLTextAreaElement> document.getElementById("console");
    if(color) console.style.color = color;
    console.textContent+=message + "\n";
}

/** Log something in the "console" textarea with no newline.
 * @param message The message to log - must have toString() method
 */
export function logOneLine(message: {toString: any}): void { // accepts anything that has a toString method
    var console = <HTMLTextAreaElement> document.getElementById("console");
    console.textContent+=message;
}

/** Log something in the "console" textarea.
 * @param message The message to log - must have toString() method
 */
export function getLog(): string { // accepts anything that has a toString method
    var console = <HTMLTextAreaElement> document.getElementById("console");
    return console.textContent;
}

/** Log something in the "console" textarea.
 * @param message The message to log - must have toString() method
 */
export function clearLog(): void { // accepts anything that has a toString method
    var console = <HTMLTextAreaElement> document.getElementById("console");
    console.textContent = "";
}

/** Will get keyboard input - for use by apps.
  */
export function getKeyboardInput(userPrompt:string, defaultValue = ""):string {
  return prompt("App says: " + userPrompt, defaultValue);
}

/** Opens a Google Maps popup at the startLat and startLng you specify,
  * with the zoom specified. Calls the callback once user exits, providing
  * them with the selected lat and lng, the name of the place,
  * and an error string.
  */
export function getPosFromMap(startLat, startLng, zoom,
    callback: (lat:number, lng:number, loc:string, err:string) => any) {
  var popup = <any>window.open("./src/gmaps_window.html", "", "width=320,height=320");
  popup.center = {lat: startLat, lng: startLng};
  popup.zoom = zoom;
  popup.callback = callback;
  //callback(-45.81827218518002, 170.61630249023438, "Port Chalmers, New Zealand", null);
}
