define(["require", "exports"], function (require, exports) {
    "use strict";
    var Events = (function () {
        function Events() {
        }
        Events.prototype.onTapEvent = function (x, y) { };
        ;
        Events.prototype.onSwipeEvent = function (startX, startY, endX, endY, orientation) { };
        ;
        return Events;
    }());
    exports.Events = Events;
    var Sensors = (function () {
        function Sensors() {
            this.sensors = {
                "gps_lat": 0,
                "gps_lon": 0,
                "ambient_light": 0,
                "height": 0,
                "accelerometer": 0,
                "magnetometer": 0,
                "heartbeat": 0,
                "blood_o2": 0,
                "blood_co2": 0,
                "conductance": 0,
                "gyroscope": 0,
                "barometer": 0,
                "temp_skin": 0,
                "temp_ambient": 0
            };
        }
        return Sensors;
    }());
    exports.Sensors = Sensors;
    function setPersistentData(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + "; " + expires;
    }
    exports.setPersistentData = setPersistentData;
    function getPersistentData(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
    exports.getPersistentData = getPersistentData;
    var App = (function () {
        function App() {
        }
        return App;
    }());
    exports.App = App;
    function log(message, color) {
        var console = document.getElementById("console");
        if (color)
            console.style.color = color;
        console.textContent += message + "\n";
    }
    exports.log = log;
    function logOneLine(message) {
        var console = document.getElementById("console");
        console.textContent += message;
    }
    exports.logOneLine = logOneLine;
    function getLog() {
        var console = document.getElementById("console");
        return console.textContent;
    }
    exports.getLog = getLog;
    function clearLog() {
        var console = document.getElementById("console");
        console.textContent = "";
    }
    exports.clearLog = clearLog;
    function getKeyboardInput(userPrompt, defaultValue) {
        if (defaultValue === void 0) { defaultValue = ""; }
        return prompt("App says: " + userPrompt, defaultValue);
    }
    exports.getKeyboardInput = getKeyboardInput;
    function getPosFromMap(startLat, startLng, zoom, callback) {
        var popup = window.open("./src/gmaps_window.html", "", "width=320,height=320");
        popup.center = { lat: startLat, lng: startLng };
        popup.zoom = zoom;
        popup.callback = callback;
    }
    exports.getPosFromMap = getPosFromMap;
});
