define(["require", "exports", "./util/util", "./util/util", "./util/util"], function (require, exports, util_1, util_2, util_3) {
    "use strict";
    function run(app) {
        var canvas = document.getElementById("screen");
        var ctx = canvas.getContext("2d");
        var appCanvas = document.createElement("canvas");
        appCanvas.width = canvas.height;
        appCanvas.height = canvas.width;
        var appCtx = appCanvas.getContext("2d");
        appCtx.fillStyle = "#ff0000";
        appCtx.fillRect(0, 0, appCanvas.width, appCanvas.height);
        var ev = new util_2.Events();
        var sensors = new util_3.Sensors();
        var dom_sensors = [];
        for (var name in sensors.sensors) {
            dom_sensors[name] = document.getElementById("sensor_" + name);
        }
        function setSensorData(sensorName) {
            var sensor = document.getElementById("sensor_" + sensorName);
            if (!sensor) {
                util_1.log(sensorName + " is null");
            }
            var sensor_data = Number(sensor.value);
            if (!isNaN(sensor_data)) {
                sensors.sensors[sensorName] = sensor_data;
                sensor.value = sensor_data.toString();
                app.sensorUpdated(sensorName);
            }
            else {
                sensor.value = sensors.sensors[sensorName].toString();
            }
        }
        ;
        for (var name in sensors.sensors) {
            setSensorData(name);
        }
        for (var name in dom_sensors) {
            dom_sensors[name].addEventListener("change", function (e) {
                setSensorData(this.id.substring("sensor_".length, this.id.length));
            });
        }
        app.init(appCanvas, ev, sensors);
        var startTime = 0;
        var date = new Date();
        var mouseDrag = {
            startX: 0,
            startY: 0,
            swipeLength: 25,
            tapLength: 10,
            endX: 0,
            endY: 0,
            dragType: function () {
                var deltaX = Math.abs(this.endX - this.startX);
                var deltaY = Math.abs(this.endY - this.startY);
                if (deltaX > deltaY) {
                    return "horizontal";
                }
                else {
                    return "vertical";
                }
            },
            getDelta: function () {
                var deltaX = Math.abs(this.endX - this.startX);
                var deltaY = Math.abs(this.endY - this.startY);
                return Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
            }
        };
        canvas.addEventListener("mousedown", function (event) {
            mouseDrag.startX = event.offsetX;
            mouseDrag.startY = event.offsetY;
        });
        canvas.addEventListener("mouseup", function (event) {
            mouseDrag.endX = event.offsetX;
            mouseDrag.endY = event.offsetY;
            if (mouseDrag.getDelta() > mouseDrag.swipeLength) {
                ev.onSwipeEvent(mouseDrag.startX, mouseDrag.startY, mouseDrag.endX, mouseDrag.endY, mouseDrag.dragType());
            }
            else if (mouseDrag.getDelta() < mouseDrag.tapLength) {
                ev.onTapEvent(mouseDrag.endX, mouseDrag.endY);
            }
        });
        function blit(src, dest) {
            var srcCtx = src.getContext("2d");
            var destCtx = dest.getContext("2d");
            var src_data = srcCtx.getImageData(0, 0, src.width, src.height);
            destCtx.putImageData(src_data, 0, 0);
        }
        (function updateAndDraw() {
            startTime = date.getTime();
            app.doTick();
            blit(appCanvas, canvas);
            setTimeout(updateAndDraw, ((1000 / 60) - (date.getTime() - startTime)));
        })();
    }
    exports.run = run;
    ;
});
