import {log} from "../../util/util";
import {getKeyboardInput} from "../../util/util";
import {Events} from "../../util/util";
import {App} from "../../util/util";
import {Sensors} from "../../util/util";

class lineObject {
  radius: number;
  toX: number;
  toY: number;
  theta: number;
  color: string;
};

class Main extends App {
  protected screen: HTMLCanvasElement;
  protected ctx: CanvasRenderingContext2D;
  protected sensors: Sensors;
  protected lastTapped: {
    x: number, y: number
  };
  protected lastSwiped: {
    startX: number, startY: number,
    endX: number, endY: number,
    orientation: string
  };
  protected animationRunning = true;
  protected title = "I'm the app";

  protected lines: lineObject[] = [];

  init(screen: HTMLCanvasElement, events: Events, sensors: Sensors) {
    // Set on tap listener
    events.onTapEvent = ((x, y) => {
      this.lastTapped = { x, y };
      this.animationRunning = !this.animationRunning;
      log("You Tapped: " + x + ", " + y);
    });
    events.onSwipeEvent = ((sX, sY, eX, eY, dir) => {
      this.lastSwiped = {
        startX: sX, startY: sY,
        endX: eX, endY: eY,
        orientation: dir
      };
      for (var obj of this.lines) {
        obj.color = '#' + Math.floor(Math.random() * 16777215).toString(16);
      }
      if (dir === "vertical") {
        this.title = getKeyboardInput("Enter title");
      } else {
        this.getTideData();
      }
      log("You swiped: (" + sX + "," + sY + ") -> (" + eX + "," + eY + "): " + dir);
    });
    this.sensors = sensors;
    this.screen = screen;
    this.ctx = screen.getContext("2d");
    this.lines[0] = {
      radius: 300,
      toX: this.screen.width / 2,
      toY: this.screen.height / 2 - 50,
      theta: 0,
      color: "#00aa00"
    };
    this.lines[1] = {
      radius: 300,
      toX: this.screen.width / 2,
      toY: this.screen.height / 2 - 50,
      theta: 0,
      color: "#ff00ff"
    };
  }
  doTick() {
    this.clearScreen();
    this.ctx.fillStyle = "#ff0000";
    this.ctx.fillText(this.title, 30, 30);
    this.ctx.fillStyle = "#0000ff";
    if (this.lastTapped != undefined) {
      this.ctx.fillText("Tapped: " + this.lastTapped.x + ", " + this.lastTapped.y, 30, 50);
    }

    // draw the sensors on screen
    var drawAt = 70;
    for (var sensor in this.sensors.sensors) {
      this.ctx.fillText(sensor + ": " + this.sensors.sensors[sensor], 30, drawAt);
      drawAt += 15;
    }

    if (this.animationRunning) {
      this.lines[0].theta -= 0.05;
    }
    this.ctx.strokeStyle = this.lines[0].color;
    this.ctx.beginPath();
    this.ctx.moveTo(this.screen.width / 2, this.screen.height / 2);
    this.ctx.lineTo(this.lines[0].toX, this.lines[0].toY);
    this.lines[0].toX = this.screen.width / 2 + this.lines[0].radius * Math.sin(this.lines[0].theta);
    this.lines[0].toY = this.screen.height / 2 + this.lines[0].radius * Math.cos(this.lines[0].theta);
    this.ctx.stroke();

    if (this.animationRunning) {
      this.lines[1].theta += 0.03;
    }
    this.ctx.strokeStyle = this.lines[1].color;
    this.ctx.beginPath();
    this.ctx.moveTo(this.screen.width / 2, this.screen.height / 2);
    this.ctx.lineTo(this.lines[1].toX, this.lines[1].toY);
    this.lines[1].toX = this.screen.width / 2 + this.lines[1].radius * Math.sin(this.lines[1].theta);
    this.lines[1].toY = this.screen.height / 2 + this.lines[1].radius * Math.cos(this.lines[1].theta);
    this.ctx.stroke();
  }
  public sensorUpdated(sensor: string): void {
    if (this.sensors) { // makes sure sensors has been initialised
      log(sensor + " updated to: " + this.sensors.sensors[sensor]);
    }
  }

  /*
  * load first screen (in __init__)
  * each screen has buttons corresponding to screentransitions
  * to other screens
  * can have overlay by drawing AFTER images have loaded..
  * store overlay as a global variable
  * keep track of what page you on
  * ^^ allows you to work out which button the coordinates hit
  */
  private screenToTransition(screenNum : number){
    //transition?
    this.clearScreen();

  }


  private clearScreen() {
    this.ctx.fillStyle = "#ffffff";
    this.ctx.fillRect(0, 0, screen.width, screen.height);
  }

  //https:www.worldtides.info/apidocs
  //managed to jack a key??  --  af967f62-eb62-4574-b75e-a9056859055e
  private getTideData(){
    var queryString:string;
    var lat:number = -45.878760;
    var lon:number = 170.502798;
    var key:string = "1d7a2d10-85cf-4c3f-a9e0-2897c9ae88f7";
    queryString = "?heights&extremes&lat="+lat+"&lon="+lon+"&length="+"1209600";
    queryString += "&maxcalls="+"5"+"&key="+key;
    this.ajaxFunction(queryString);

  }

  private ajaxFunction(query:string) {
    var ajaxRequest;
    var apiUrl:string = "https://www.worldtides.info/api";
    try{
      ajaxRequest = new XMLHttpRequest();
    }catch(e){
      try{
        ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
      }catch(e){
        try{
          ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
        }catch(e){
          log("Something went wrong with making the ajaxRequest");
          return false;
        }
      }
    }
    ajaxRequest.open("GET", apiUrl + query, true);
    ajaxRequest.responseType = 'json';
    ajaxRequest.onreadystatechange = function(){
      var status:number;
      var data;
      if(ajaxRequest.readyState == 4){
        status = ajaxRequest.status;
        if(status == 200){

          log(JSON.stringify(ajaxRequest.response));
          //this is where our handler goes
        }else{
          //handle error
          log(JSON.stringify(ajaxRequest.response));
        }
      }
    }
    ajaxRequest.send(); // hmmm.
  }
  // jquery example of ajax
  // $.ajax({
  //     url: 'querystring',
  //     contentType: 'application/json'
  //     dataType: 'json',
  //     complete: function(data){
  //         alert(data)
  //     },
  //     success: function(data){
  //         alert(data)
  //     }

}

export {Main};
