import {log} from "./util/util";
import {Events} from "./util/util";
import {App} from "./util/util";
import {Sensors} from "./util/util";

function run(app:App) {
  let canvas = <HTMLCanvasElement>document.getElementById("screen");
  let ctx = canvas.getContext("2d");

  let appCanvas: HTMLCanvasElement = <HTMLCanvasElement>document.createElement("canvas");
  appCanvas.width = canvas.height;
  appCanvas.height = canvas.width;

  let appCtx = appCanvas.getContext("2d");
  appCtx.fillStyle = "#ff0000";
  appCtx.fillRect(0, 0, appCanvas.width, appCanvas.height);

  let ev: Events = new Events();

  let sensors: Sensors = new Sensors();
  let dom_sensors: HTMLInputElement[] = [];
  for (var name in sensors.sensors) {
    dom_sensors[name] = <HTMLInputElement>document.getElementById("sensor_" + name);
  }


  /** Sets the data in the sensor object, from the id supplied.
    * @param sensorName the name of the sensor whose value to set.
    */
  function setSensorData(sensorName: string): void {
    let sensor: HTMLInputElement = <HTMLInputElement>document.getElementById("sensor_" + sensorName);
    if(!sensor) {
      log(sensorName + " is null");
    }
    let sensor_data = Number(sensor.value);
    if (!isNaN(sensor_data)) {
      sensors.sensors[sensorName] = sensor_data;
      sensor.value = sensor_data.toString();
      app.sensorUpdated(sensorName);
    } else {
      sensor.value = sensors.sensors[sensorName].toString();
    }
  };

  // Initialise the values of the sensors object from the HTMLInputElements
  for (var name in sensors.sensors) {
    setSensorData(name);
  }

  for (var name in dom_sensors) {
    dom_sensors[name].addEventListener("change", function(e: Event) {
      // have to do some messy cutting to remove "sensor_" from start

      // note - can't just use "setSensorData(name)" because of some weird,
      // insidious scoping rules that means "name" refers to the last used
      // name inside of this listener (try it, see what happens)
      setSensorData(this.id.substring("sensor_".length, this.id.length));
    });
  }

  app.init(appCanvas, ev, sensors);

  var startTime: number = 0;
  var date: Date = new Date();

  /** MouseDrag object wraps up "swipes" cleanly, has convenience methods
    * for getting length of swipe and orientation of swipes
    */
  let mouseDrag: {
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    swipeLength: number,
    tapLength: number,
    dragType(): string,
    getDelta(): number
  } = {
      startX: 0,
      startY: 0,
      swipeLength: 25, // note that 25 here is a magic number - 25 just "feels" about right
      // for the length of the swipe.
      tapLength: 10, // the length that you can move and still have it counted as a tap.
      // is also just a magic number
      endX: 0,
      endY: 0,
      dragType: function(): string {
        let deltaX = Math.abs(this.endX - this.startX);
        let deltaY = Math.abs(this.endY - this.startY);
        if (deltaX > deltaY) {
          return "horizontal";
        }
        else {
          return "vertical";
        }
      },
      getDelta: function(): number {
        // little bit of pythagoras
        let deltaX = Math.abs(this.endX - this.startX);
        let deltaY = Math.abs(this.endY - this.startY);
        //log("dX: " + deltaX + " dY: " + deltaY);
        return Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
      }
    };

  canvas.addEventListener("mousedown", (event: MouseEvent) => {
    mouseDrag.startX = event.offsetX;
    mouseDrag.startY = event.offsetY;
  });

  canvas.addEventListener("mouseup", (event: MouseEvent) => {
    mouseDrag.endX = event.offsetX;
    mouseDrag.endY = event.offsetY;
    if (mouseDrag.getDelta() > mouseDrag.swipeLength) {
      ev.onSwipeEvent(mouseDrag.startX, mouseDrag.startY,
        mouseDrag.endX, mouseDrag.endY,
        mouseDrag.dragType());
    } else if (mouseDrag.getDelta() < mouseDrag.tapLength) {
      ev.onTapEvent(mouseDrag.endX, mouseDrag.endY);
    }
    //log("dragged " + mouseDrag.getDelta() + ", " + mouseDrag.dragType());
  });


  /** Blit one canvas onto another.
   * @param src The source canvas
   * @param dest The destination canvas
   */
  function blit(src: HTMLCanvasElement, dest: HTMLCanvasElement): void {
    var srcCtx = src.getContext("2d");
    var destCtx = dest.getContext("2d");

    var src_data = srcCtx.getImageData(0, 0, src.width, src.height);
    destCtx.putImageData(src_data, 0, 0);
  }

  (function updateAndDraw(): void {
    startTime = date.getTime();
    app.doTick();
    blit(appCanvas, canvas);
    setTimeout(updateAndDraw, ((1000 / 60) - (date.getTime() - startTime)));
  })();
};

export {run};
